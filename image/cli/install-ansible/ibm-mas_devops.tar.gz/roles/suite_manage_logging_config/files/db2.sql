delete from maximo.APIROUTE where ROUTE IN ('toolslog','icheckerrepair','managestart','icheckerreport','managestop');

COMMIT;
